import os
import time
import logging
from datetime import datetime

# --- КОНФІГУРАЦІЯ ШЛЯХІВ ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
FLAG_MOMENT = os.path.join(SCRIPT_DIR, "moment_active.flag")
FLAG_ALARM = os.path.join(SCRIPT_DIR, "alarm_active.flag")
FLAG_CANCEL = os.path.join(SCRIPT_DIR, "cancel_active.flag")
LOG_FILE = os.path.join(SCRIPT_DIR, "scheduler.log")

logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - [MOMENT_SCHEDULER] %(message)s',
    handlers=[logging.FileHandler(LOG_FILE, encoding='utf-8'), logging.StreamHandler()]
)

def clear_all_flags():
    """Видаляє всі робочі файли-прапорці для чистого стану системи."""
    for f in [FLAG_MOMENT, FLAG_ALARM, FLAG_CANCEL]:
        if os.path.exists(f):
            try:
                os.remove(f)
                logging.debug(f"🗑️ Очищено файл: {f}")
            except Exception as e:
                logging.error(f"❌ Не вдалося видалити {f}: {e}")

def should_create_moment_flag(now: datetime, last_played_date: str) -> bool:
    """Перевірка: чи настав час 09:00 і чи ще не грали сьогодні."""
    today_str = now.strftime('%Y-%m-%d')
    return now.hour == 9 and now.minute == 0 and last_played_date != today_str

def start_scheduler():
    logging.info("--- ПЛАНУВАЛЬНИК ЗАПУЩЕНО (Очікування 09:00) ---")
    
    # Очищуємо все при запуску, щоб не було конфліктів з плеєром
    clear_all_flags()
    
    last_played_date = ""

    try:
        while True:
            now = datetime.now()
            today_str = now.strftime('%Y-%m-%d')

            # Логіка створення прапорця хвилини мовчання
            if should_create_moment_flag(now, last_played_date):
                # Додаткова страховка: чистимо, щоб не було колізій
                clear_all_flags()
                
                logging.info(f"🕯️ 09:00! Створюю флаг хвилини мовчання для {today_str}...")
                with open(FLAG_MOMENT, "w", encoding="utf-8") as f:
                    f.write(f"start_{today_str}_{now.strftime('%H:%M:%S')}")
                
                last_played_date = today_str
                logging.info("✅ Флаг створено. Очікуємо завтра.")

            # Енергоефективний сон: частіше перевіряємо біля 09:00, рідше в інший час
            if now.hour == 8 and now.minute >= 59:
                time.sleep(5)
            else:
                time.sleep(30)
            
        
            
    except KeyboardInterrupt:
        logging.info("Планувальник зупинено.")
    except Exception as e:
        logging.critical(f"Критична помилка: {e}")

if __name__ == "__main__":
    start_scheduler()