import winsound
import os
import time
import logging

# --- КОНФІГУРАЦІЯ ШЛЯХІВ ---
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

SOUND_ALARM = os.path.join(BASE_DIR, "static", "audio", "alarm.wav")
SOUND_CANCEL = os.path.join(BASE_DIR, "static", "audio", "cancel.wav")
SOUND_MOMENT = os.path.join(BASE_DIR, "static", "audio", "moment.wav")

FLAGS = {
    "alarm": os.path.join(SCRIPT_DIR, "alarm_active.flag"),
    "cancel": os.path.join(SCRIPT_DIR, "cancel_active.flag"),
    "moment": os.path.join(SCRIPT_DIR, "moment_active.flag")
}

STATE_FILE = os.path.join(SCRIPT_DIR, "alarm_running.state")

logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s [%(levelname)s]: %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(SCRIPT_DIR, "player.log"), encoding='utf-8'),
        logging.StreamHandler()
    ]
)

def stop_all_audio():
    try: winsound.PlaySound(None, winsound.SND_ASYNC)
    except: pass

def safe_remove(path):
    try:
        if os.path.exists(path): os.remove(path)
    except Exception as e:
        logging.debug(f"Не вдалося видалити: {e}")

def play_sound_file(path):
    if not os.path.exists(path): return False
    try:
        stop_all_audio()
        winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC)
        return True
    except: return False

def main():
    logging.info("🔊 Player Service запущено")
    start_time = time.time()
    safe_remove(STATE_FILE)

    while True:
        # 1. ПЕРЕВІРКА ТРИВОГИ
        if os.path.exists(FLAGS["alarm"]):
            if not os.path.exists(STATE_FILE):
                logging.info("🚨 Початок тривоги!")
                if play_sound_file(SOUND_ALARM):
                    with open(STATE_FILE, "w") as f: f.write("playing")
            time.sleep(1)
            continue

        # 2. ПЕРЕВІРКА ВІДБОЮ
        if os.path.exists(FLAGS["cancel"]):
            # ЗАХИСТ: Блокуємо, якщо зараз йде хвилина мовчання
            if os.path.exists(FLAGS["moment"]):
                logging.warning("🚫 Заблоковано фантомний CANCEL під час мовчання")
                safe_remove(FLAGS["cancel"])
                continue
                
            # Фільтр: ігноруємо старі файли при старті та випадкові файли без тривоги
            if os.path.exists(STATE_FILE) and (time.time() - start_time > 5):
                logging.info("✅ Отримано сигнал: ВІДБІЙ (підтверджено)")
                play_sound_file(SOUND_CANCEL)
                time.sleep(12)
                safe_remove(STATE_FILE)
            else:
                logging.warning("⚠️ Фантомний сигнал CANCEL ігноровано")
            
            safe_remove(FLAGS["cancel"])
            continue

        # 3. ХВИЛИНА МОВЧАННЯ
        if os.path.exists(FLAGS["moment"]):
            if not os.path.exists(STATE_FILE):
                logging.info("🕯️ Початок хвилини мовчання")
                play_sound_file(SOUND_MOMENT)
                
                # Чекаємо 65 секунд або переривання
                wait_start = time.time()
                while time.time() - wait_start < 65:
                    if os.path.exists(FLAGS["alarm"]):
                        logging.info("🚨 Мовчання перервано тривогою! (Файл alarm_active.flag знайдено)")
                        stop_all_audio()
                        break
                    # Блок відладки
                    if not os.path.exists(FLAGS["moment"]):
                        logging.info("🚫 Хвилина мовчання перервана: файл moment_active.flag було видалено іншим процесом!")
                        stop_all_audio()
                        break
                    time.sleep(1)
                
                stop_all_audio()
            
            safe_remove(FLAGS["moment"])
            logging.info("✅ Хвилина мовчання завершена (тихо)")
            continue

        time.sleep(1)

if __name__ == "__main__":
    main()