let audioEnabled = false;
let lastState = 'init'; // Змінено для коректного старту
let stateStartTime = Date.now();
let localTestMode = false;

function formatTime(ms) {
    let s = Math.floor(ms / 1000);
    let h = Math.floor(s / 3600);
    let m = Math.floor((s % 3600) / 60);
    s = s % 60;
    return [h, m, s].map(v => v < 10 ? '0' + v : v).join(':');
}

// Покращена активація аудіо
function enableAudio() {
    audioEnabled = true;
    const gate = document.getElementById('audio-status');
    if (gate) {
        gate.innerText = "✅ СИСТЕМА АКТИВОВАНА";
        gate.classList.add('active');
    }
    // "Прогріваємо" аудіо елементи (потрібно для Chrome/Safari)
    ['snd-alarm', 'snd-cancel', 'snd-moment'].forEach(id => {
        const a = document.getElementById(id);
        if (a) {
            a.muted = true; // Робимо тихим перед "прогрівом"
            a.play().then(() => { a.pause(); a.currentTime = 0; a.muted = false; }).catch(() => {});
        }
    });
}

function stopAllLocalSounds() {
    ['snd-alarm', 'snd-cancel', 'snd-moment'].forEach(id => {
        const a = document.getElementById(id);
        if (a) { a.pause(); a.currentTime = 0; }
    });
}

async function update() {
    try {
        const r = await fetch('/status');
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        const data = await r.json();
        
        const st = document.getElementById('status-text');
        const dur = document.getElementById('status-duration');
        const sTime = document.getElementById('server-time');
        
        if (st) {
            st.innerText = data.status_text;
            st.style.color = data.is_alarm ? 'var(--error)' : (data.is_moment ? 'var(--warning)' : 'var(--accent)');
            // Додаємо класи для анімації з CSS
            st.className = 'status-val ' + (data.is_alarm ? 'alert-mode' : 'clear-mode');
        }
        if (sTime) sTime.innerText = "Час сервера: " + data.server_time;

        // Логіка звуку
        if (audioEnabled && !localTestMode) {
            let newState = 'clear';
            if (data.is_moment) newState = 'moment';
            else if (data.is_alarm) newState = 'alarm';

            if (newState !== lastState) {
                stopAllLocalSounds();
                if (newState === 'moment') document.getElementById('snd-moment').play();
                else if (newState === 'alarm') document.getElementById('snd-alarm').play();
                else if (lastState === 'alarm') document.getElementById('snd-cancel').play();
                
                lastState = newState;
                stateStartTime = Date.now();
            }
        }
        
        if (dur) dur.innerText = "Тривалість: " + formatTime(Date.now() - stateStartTime);

        // Оновлення карток
        ['monitor', 'player', 'scheduler'].forEach(name => {
            const isActive = data.scripts[name] === 'ПРАЦЮЄ';
            const card = document.getElementById('card-' + name);
            const btn = document.getElementById('btn-' + name);
            const logBox = document.getElementById('log-' + name);
            
            if (card) card.className = 'script-card' + (isActive ? ' active' : '');
            
            if (btn) {
                btn.innerText = isActive ? "УВІМК" : "ВИМК";
                btn.className = "btn-start " + (isActive ? "on" : "off");
            }
            
            if (logBox) {
                const newLog = data.logs[name] || "Логи порожні...";
                if (logBox.innerText.trim() !== newLog.trim()) {
                    logBox.innerText = newLog;
                    logBox.scrollTop = logBox.scrollHeight;
                }
            }
        });
    } catch (e) {
        console.error("Update error:", e);
        const st = document.getElementById('status-text');
        if (st) { st.innerText = "ОФЛАЙН"; st.style.color = "var(--error)"; }
    }
}

setInterval(update, 2000);
update();