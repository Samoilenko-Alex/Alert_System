﻿import os
import subprocess
import atexit
from datetime import datetime
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS

# Налаштування вказує на C:\kyiv_alert\alert_monitor\static
app = Flask(__name__, static_folder='alert_monitor/static', template_folder='templates')
CORS(app, resources={r"/*": {"origins": "*"}})

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# --- КОНФІГУРАЦІЯ ---
PYTHON_EXE = r"C:\kyiv_alert\venv\Scripts\python.exe"
BASE_DIR = r"C:\kyiv_alert\alert_monitor"
os.makedirs(BASE_DIR, exist_ok=True)

SCRIPTS = {
    "monitor": os.path.join(BASE_DIR, "monitor.py"),
    "player": os.path.join(BASE_DIR, "player_service.py"),
    "scheduler": os.path.join(BASE_DIR, "moment_scheduler.py")
}

FLAGS = {
    "alarm": os.path.join(BASE_DIR, "alarm_active.flag"),
    "cancel": os.path.join(BASE_DIR, "cancel_active.flag"),
    "moment": os.path.join(BASE_DIR, "moment_active.flag")
}

active_resources = {name: {"proc": None, "file": None} for name in SCRIPTS}

# --- ФУНКЦІЇ ---
def get_tail(name, lines_count=20):
    path = os.path.join(BASE_DIR, f"{name}.log")
    if not os.path.exists(path): return "📡 Очікування ініціалізації логів..."
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return "".join(f.readlines()[-lines_count:])
    except Exception as e:
        return f"⚠️ Помилка логу {name}: {e}"

def is_running(name):
    res = active_resources.get(name)
    if res and res["proc"] and res["proc"].poll() is None: return True
    if name == "player":
        lock_file = os.path.join(BASE_DIR, "player_lock.lock")
        if os.path.exists(lock_file):
            try:
                with open(lock_file, "r") as f: pid = int(f.read().strip())
                os.kill(pid, 0)
                return True
            except (OSError, ValueError): return False
    return False

def stop_script(name):
    res = active_resources[name]
    if res["proc"] and res["proc"].poll() is None:
        try:
            subprocess.run(['taskkill', '/F', '/T', '/PID', str(res["proc"].pid)], capture_output=True)
            res["proc"].wait(timeout=1)
        except: res["proc"].kill()
    if name == "player" and os.path.exists(os.path.join(BASE_DIR, "player_lock.lock")):
        try: os.remove(os.path.join(BASE_DIR, "player_lock.lock"))
        except: pass
    if res["file"]: res["file"].close()
    active_resources[name] = {"proc": None, "file": None}

def start_script(name):
    if name not in SCRIPTS or not os.path.exists(SCRIPTS[name]): return
    stop_script(name)
    log_file = open(os.path.join(BASE_DIR, f"{name}.log"), "a", encoding="utf-8")
    env = os.environ.copy()
    env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
    proc = subprocess.Popen([PYTHON_EXE, "-u", SCRIPTS[name]], stdout=log_file, stderr=log_file, 
                            cwd=BASE_DIR, env=env, creationflags=subprocess.CREATE_NEW_PROCESS_GROUP)
    active_resources[name] = {"proc": proc, "file": log_file}

def clear_all_flags():
    for path in FLAGS.values():
        if os.path.exists(path):
            try: os.remove(path)
            except: pass

@atexit.register
def cleanup_on_exit():
    for name in SCRIPTS: stop_script(name)

# --- РОУТИ ---
@app.route('/')
def index(): return render_template('index.html')

@app.route('/status')
def get_status():
    is_alarm = os.path.exists(FLAGS["alarm"])
    is_moment = os.path.exists(FLAGS["moment"])
    status_text = "🕯️ ХВИЛИНА МОВЧАННЯ" if is_moment else ("🚨 ПОВІТРЯНА ТРИВОГА" if is_alarm else "⚪ ЧИСТО")
    return jsonify({
        "status_text": status_text, "is_alarm": is_alarm, "is_moment": is_moment,
        "scripts": {n: ("ПРАЦЮЄ" if is_running(n) else "ЗУПИНЕНО") for n in active_resources},
        "logs": {name: get_tail(name) for name in SCRIPTS},
        "server_time": datetime.now().strftime("%H:%M:%S")
    })

@app.route('/toggle/<name>')
def toggle_script(name):
    if name not in SCRIPTS: return "Error", 400
    if is_running(name): stop_script(name)
    else: start_script(name)
    return jsonify({"status": "ok"})

@app.route('/manual/<action>')
def manual_trigger(action):
    # Логування запиту для відладки, якщо виникне повторна проблема
    print(f"DEBUG: Manual trigger action: {action}")
    
    if action == "stop_all": 
        clear_all_flags()
        return jsonify({"status": "cleared"})
    
    key = action.replace("test_", "")
    
    if key == "cancel":
        # ЛОГІКА ВІДБОЮ: НЕ чіпаємо момент, ми лише хочемо зупинити тривогу
        if os.path.exists(FLAGS["alarm"]):
            with open(FLAGS["cancel"], "w", encoding="utf-8") as f: 
                f.write(str(datetime.now()))
        else:
            return jsonify({"status": "ignored", "reason": "no_alarm_active"})
            
    elif key in FLAGS:
        # ЛОГІКА ДЛЯ АЛАРМУ АБО МОМЕНТУ
        with open(FLAGS[key], "w", encoding="utf-8") as f: 
            f.write(str(datetime.now()))
            
    return jsonify({"status": "ok"})

@app.route('/clear_logs')
def clear_logs():
    for name in SCRIPTS:
        path = os.path.join(BASE_DIR, f"{name}.log")
        if os.path.exists(path): open(path, 'w').close()
    return jsonify({"status": "ok"})

if __name__ == '__main__':
    clear_all_flags()
    for name in SCRIPTS: start_script(name)
    app.run(host='0.0.0.0', port=5000, debug=False)