# 🚨 Kyiv Alert Monitor System

**Автоматизована система моніторингу повітряних тривог по Києву** з відтворенням сирени, сигналу відбою та хвилини мовчання.

Система призначена для використання на комп’ютерах, гучномовцях та аудіосистемах у громадських місцях, офісах, бомбосховищах та інших об’єктах.

---

## Основні можливості

- Реальний моніторинг повітряних тривог через офіційний API `ukrainealarm.com`
- Сирена відтворюється **один раз** при початку тривоги (не зациклюється)
- Автоматична хвилина мовчання щодня о **09:00** точно
- Сигнал відбою при закінченні тривоги
- Зручна веб-панель керування (доступна з будь-якого пристрою в мережі)
- Підтримка роботи на кількох ПК одночасно
- Історія тривог та детальне логування
- Інструменти тестування та симуляції

---

## Структура проекту
C:\kyiv_alert/
├── alert_monitor/
│   ├── monitor.py                  # Моніторинг API UkraineAlarm
│   ├── player_service.py           # Аудіоплеєр (основний звук)
│   ├── moment_scheduler.py         # Планувальник хвилини мовчання
│   ├── web_app.py                  # Flask веб-сервер + управління
│   ├── alerts_history.json         # Історія тривог
│   └── *.log                       # Логи
├── silence_moment/
│   ├── alarm.wav
│   ├── cancel.wav
│   └── moment.wav
├── templates/
│   └── index.html                  # Веб-панель керування
├── simulate_alert.py               # Симулятор тривог
├── start_all.bat                   # Автозапуск усієї системи
├── test_system.py                  # Повний тест системи
├── requirements.txt
└── README.md
text---

## Пріоритети подій

1. **Повітряна тривога** (найвищий пріоритет)  
   Файл-флаг: `alarm_active.flag`  
   Звук: `alarm.wav` (відтворюється **один раз**)

2. **Відбій тривоги**  
   Файл-флаг: `cancel_active.flag`  
   Звук: `cancel.wav` (одноразовий сигнал)

3. **Хвилина мовчання** (нижчий пріоритет)  
   Файл-флаг: `moment_active.flag`  
   Звук: `moment.wav` (відтворюється один раз)

**Правила роботи:**
1. **Повітряна тривога** — `alarm_active.flag` → `alarm.wav` (один раз)
2. **Відбій тривоги** — `cancel_active.flag` → `cancel.wav`
3. **Хвилина мовчання** — `moment_active.flag` → `moment.wav` (один раз)

> Примітка: Тривога може перервати хвилину мовчання.

---

## Встановлення та запуск

### 1. Підготовка середовища
```powershell
cd C:\kyiv_alert
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
2. Запуск системи
Рекомендований спосіб (найпростіший):
PowerShell.\start_all.bat
(Запускати від імені адміністратора)
Або вручну в окремих вікнах PowerShell:
PowerShell.\venv\Scripts\python.exe .\alert_monitor\player_service.py
.\venv\Scripts\python.exe .\alert_monitor\monitor.py
.\venv\Scripts\python.exe .\alert_monitor\moment_scheduler.py
.\venv\Scripts\python.exe .\web_app.py
Після запуску відкрийте в браузері:
http://localhost:5000

Керування
Через веб-панель

Вмикання / вимикання скриптів (Monitor, Player, Scheduler)
Запуск тестів (тривога, відбій, хвилина мовчання)
Аварійна зупинка (Emergency Stop)
Перегляд логів у реальному часі

Через командний рядок
PowerShellpython simulate_alert.py alarm      # Імітувати тривогу
python simulate_alert.py cancel     # Імітувати відбій
python simulate_alert.py moment     # Імітувати хвилину мовчання
python simulate_alert.py clear      # Очистити всі флаги

Тестування
PowerShell python test_system.py               # Повний тест системи

Важливі технічні моменти

Система працює через механізм файлів-флагів
player_service.py захищений від подвійного запуску (player_lock.lock)
Обов'язково вимкнути сплячий режим комп’ютера
Для стабільної роботи запускати скрипти від імені адміністратора


Файли логів

alert_monitor/player.log — аудіоплеєр
alert_monitor/monitor.log — моніторинг API
alert_monitor/scheduler.log — планувальник
alert_monitor/web_app.log — веб-сервер


Статус проекту
MVP версія готова до використання.
У подальшому планується зміна пріоритезації, гнучкі налаштування та розширення функціоналу.

Автор: Oleksandr Samoilenko
Версія: 1.0 (2026)
